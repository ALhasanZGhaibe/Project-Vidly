﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vedly.Models
{
    public class RoleName
    {
        public const string CanManageMovies = "CanManageMovies";
        public const string CanManageCustomers = "CanManageCustomers";
    }
}