﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Vedly.Models
{
    public class Genre
    {
        public Byte Id { get; set; }
        public String Name { get; set; }
    }
}